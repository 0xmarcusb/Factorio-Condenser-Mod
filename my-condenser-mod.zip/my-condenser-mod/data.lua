local condensing_cat = {
    name = "condensing",
    type = "recipe-category",
    
  }

  local condenser_running = {
	type = "recipe",
	name = "condenser_running",
	energy_required = 20,
	category = "condensing",
    icon = "__my-condenser-mod__/graphics/condenser.png",
    icon_size = 64,
	enabled = true,
    made_in = "condenser_entity",
	ingredients = {},
	results = {{"sulfur",1}},
    main_product= "",
    subgroup = "fluid-recipes"
}
local condenser_item = {
	type = "item",
	name = "condenser",
	icon = "__my-condenser-mod__/graphics/condenser.png",
	icon_size = 64,
	flags = {},
	subgroup = "production-machine",
	order = "z",
	place_result = "condenser",
	stack_size = 10
}
local condenser_recipe = {
	type = "recipe",
	name = "condenser",
	energy_required = 8,
	category = "crafting-with-fluid",
	enabled = "true",
	ingredients = {
		{"steel-plate", 12},
		{"electric-engine-unit", 10},
		{"advanced-circuit", 16},
		{"pipe", 10},
		{"copper-cable", 10},
		{type="fluid",name="lubricant",amount=100}
	},
	result = "condenser"
}
local condenser_entity = {
	type = "assembling-machine",
	energy_usage = "300kW",
	name = "condenser",
	crafting_categories = {"condensing"},
	fixed_recipe = "condenser_running",
	crafting_speed = "1",
	has_backer_name = true,
	icon = "__my-condenser-mod__/graphics/condenser.png",
	icon_size = 64,
	flags = {"placeable-neutral", "player-creation"},
	minable = {
		mining_time = 2,
		result = "condenser"
	},
	collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
	selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
	
	
	
	energy_source = {
		type = "electric",
		usage_priority = "secondary-input",
		emissions_per_minute = -.1
	},
	effectivity = 1,
	burns_fluid = true,
	max_health = 300,
	resistances = {{
			type = "fire",
			percent = 70
	}},
	corpse = "big-remnants",
	vehicle_impact_sound = {
		filename = "__base__/sound/car-metal-impact.ogg",
		volume = 0.65
	},
	
	
	min_perceived_performance = 0.4,
	performance_to_sound_speedup = 0.2
}


data:extend({
	condenser_item,
	condenser_recipe,
	condenser_entity,
	condensing_cat,
	condenser_running
})